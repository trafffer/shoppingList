package com.ex.prep.model.entity.enums;

public enum CategoryNames {
    FOOD, DRINK, HOUSEHOLD, OTHER
}

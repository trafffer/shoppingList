package com.ex.prep.model.constant;

public class Constant {
    public final static String BINDING = "org.springframework.validation.BindingResult.";
}
